from flask import Flask, render_template, request, redirect, url_for

app = Flask('__name__')


@app.route('/', methods=['GET', 'POST'])
def inicio():

    if request.method == 'POST':

        name = request.form['name']
        cedula = request.form['cedula']
        telefono = request.form['telefono']

        f = open("registros.txt", "a")
        f.write("\n//////////////////////////////////////////////////////")
        f.write("\nNombre : " + name + '\nCedula : ' + cedula + '\nTelefono : ' + telefono)
        f.close()

        return redirect(url_for('q1'))

    return render_template('inicio.html')



@app.route('/q1', methods=['GET', 'POST'])
def q1():

    if 'fumar' in request.form.values():

        question_1 = "Me gusta el area de fumadores"
        f = open("registros.txt", "a")
        f.write("\n¿Que te gusta de la oficina?: ")
        f.write(question_1)
        f.close()

        return redirect('q2')

    elif 'piscina' in request.form.values():

        question_1 = "Me gusta la piscina"
        f = open("registros.txt", "a")
        f.write("\n¿Que te gusta de la oficina?: ")
        f.write(question_1)
        f.close()

        return redirect(url_for('q2'))

    elif 'secretaria' in request.form.values():

        question_1 = "Me gusta la secretaria"
        f = open("registros.txt", "a")
        f.write("\n¿Que te gusta de la oficina?: ")
        f.write(question_1)
        f.close()

        return redirect(url_for('q2'))

    elif 'jefe' in request.form.values():

        question_1 = "Me gusta el jefe"
        f = open("registros.txt", "a")
        f.write("\n¿Que te gusta de la oficina?: ")
        f.write(question_1)
        f.close()

        return redirect(url_for('q2'))

    return render_template('q1.html')

@app.route('/q2', methods=['GET', 'POST'])
def q2():

    if 'jefe_1' in request.form.values():

        question_2 = "El jefe no es muy buena persona"
        f = open("registros.txt", "a")
        f.write("\n¿Que no te gusta de la oficina?: ")
        f.write(question_2)
        f.close()
        return redirect(url_for('q3'))

    elif 'edificio' in request.form.values():

        question_2 = "No me gusta el edificio"
        f = open("registros.txt", "a")
        f.write("\n¿Que no te gusta de la oficina?: ")
        f.write(question_2)
        f.close()

        return redirect(url_for('q3'))

    elif 'estacionamiento' in request.form.values():

        question_2 = "Considero que deberian de mejorar los estacionamientos"
        f = open("registros.txt", "a")
        f.write("\n¿Que no te gusta de la oficina?: ")
        f.write(question_2)
        f.close()

        return redirect(url_for('q3'))

    elif 'cafe' in request.form.values():

        question_2 = "No me gusta el cafe de la oficina porque no pueden ser mas generosos y comprar algo de calidad."
        f = open("registros.txt", "a")
        f.write("\n¿Que no te gusta de la oficina?: ")
        f.write(question_2)
        f.close()

        return redirect(url_for('q3'))

    return render_template('q2.html')

@app.route('/q3', methods=['GET', 'POST'])
def q3():

    if '1' in request.form.values():

        question_3 = "1"
        r_3 = request.form['r_3']
        f = open("registros.txt", "a")
        f.write("\n¿Calificacion servicio de limpieza?: ")
        f.write(question_3 + '\n¿por que? : ' + r_3)
        f.close()
        return redirect(url_for('q4'))

    elif '2' in request.form.values():

        question_3 = "2"
        r_3 = request.form['r_3']
        f = open("registros.txt", "a")
        f.write("\n¿Calificacion servicio de limpieza?: ")
        f.write(question_3 + '\n¿por que? : ' + r_3)
        f.close()

        return redirect(url_for('q4'))

    elif '3' in request.form.values():

        question_3 = "3"
        r_3 = request.form['r_3']
        f = open("registros.txt", "a")
        f.write("\n¿Calificacion servicio de limpieza?: ")
        f.write(question_3 + '\n¿por que? : ' + r_3)
        f.close()

        return redirect(url_for('q4'))

    elif '4' in request.form.values():

        question_3 = "4"
        r_3 = request.form['r_3']
        f = open("registros.txt", "a")
        f.write("\n¿Calificacion servicio de limpieza?")
        f.write(question_3 + '\n¿por que? : ' + r_3)
        f.close()

        return redirect(url_for('q4'))

    elif '5' in request.form.values():

        question_3 = '5'
        r_3 = request.form['r_3']
        f = open("registros.txt", "a")
        f.write("\n¿Calificacion servicio de limpieza?")
        f.write(question_3 + '\n¿por que? : ' + r_3)
        f.close()

        return redirect(url_for('q4'))

    return render_template('q3.html')

@app.route('/q4', methods=['GET','POST'])
def q4():

    if request.method == 'POST':

        r_4 = request.form['r_4']
        f = open("registros.txt", "a")
        f.write("\n¿Opiniones sobre los guardias de seguridad?: ")
        f.write("\n" + r_4)
        f.close()

        return redirect(url_for('q5'))

    return render_template('q4.html')

@app.route('/q5', methods=['GET', 'POST'])
def q5():

    if 'muebles' in request.form.values():

        question_5 = "Cambiaria los muebles actuales por muebles hechos con piel de panda"
        f = open("registros.txt", "a")
        f.write("\n¿Que cambiarias del PB?: ")
        f.write(question_5)
        f.close()
        return redirect(url_for('q6'))

    elif 'plantas' in request.form.values():

        question_5 = "Cambiaria las plantas"
        f = open("registros.txt", "a")
        f.write("\n¿Que cambiarias del PB?: ")
        f.write(question_5)
        f.close()

        return redirect(url_for('q6'))

    elif 'secretaria_3' in request.form.values():

        question_5 = "Cambiaria por otra secretaria, la actual nos da mala imagen."
        f = open("registros.txt", "a")
        f.write("\n¿Que cambiarias del PB?: ")
        f.write(question_5)
        f.close()
        return redirect(url_for('q6'))


    return render_template('q5.html')

@app.route('/q6', methods=['GET', 'POST'])
def q6():

    if 'informatica' in request.form.values():

        question_6 = "Considero que el departamento de informatica no sirve"
        f = open("registros.txt", "a")
        f.write("\n¿Que departamento quitarias?: ")
        f.write(question_6)
        f.close()

        return redirect(url_for('q7'))

    elif 'servicios' in request.form.values():

        question_6 = "Considero que el departamento de servicios no sirve"
        f = open("registros.txt", "a")
        f.write("\n¿Que departamento quitarias?: ")
        f.write(question_6)
        f.close()

        return redirect(url_for('q7'))

    elif 'mensajeria' in request.form.values():

        question_6 = "Considero que el departamento de mensajeria no sirve"
        f = open("registros.txt", "a")
        f.write("\n¿Que departamento quitarias?: ")
        f.write(question_6)
        f.close()

        return redirect(url_for('q7'))

    elif 'nada' in request.form.values():

        question_6 = "Ninguno, todos son utiles"
        f = open("registros.txt", "a")
        f.write("\n¿Que departamento quitarias?: ")
        f.write(question_6)
        f.close()

        return redirect(url_for('q7'))

    return render_template('q6.html')

@app.route('/q7', methods=['GET', 'POST'])
def q7():

    if request.method == 'POST':

        r_7 = request.form['r_7']
        f = open("registros.txt", "a")
        f.write("\n¿Opiniones sobre Jefe de tu departamento?: ")
        f.write("\n" + r_7)
        f.close()

        return redirect(url_for('q8'))

    return render_template('q7.html')


@app.route('/q8', methods=['GET', 'POST'])
def q8():

    if 'si' in request.form.values():

        question_8 = 'Si'
        r_8 = request.form['r_8']
        f = open("registros.txt", "a")
        f.write("\n¿Has sido acosado sexualmente en el trabajo??: ")
        f.write("\n" + question_8 + "\n¡Detalles de lo ocurrido! : " + r_8)
        f.close()

        return redirect(url_for('q9'))



    elif 'no' in request.form.values():

        question_8 = 'No'
        r_8 = "no ha habido acoso hasta el momento...."
        f = open("registros.txt", "a")
        f.write("\n¿Has sido acosado sexualmente en el trabajo??: ")
        f.write("\n" + question_8 + "\t" + r_8)
        f.close()

        return redirect(url_for('q9'))

    return render_template('q8.html')


@app.route('/q9', methods=['GET', 'POST'])
def q9():

    if request.method == 'POST':

        r_9 = request.form['r_9']
        f = open("registros.txt", "a")
        f.write("\nSugerencias para subir la calidad de nuestros productos y/o servicios: ")
        f.write("\n" + r_9)
        f.close()

        return redirect(url_for('q10'))

    return render_template('q9.html')

@app.route('/q10', methods=['GET', 'POST'])
def q10():

    if '1' in request.form.values():

        question_10 = "1"
        r_10 = request.form['r_10']
        f = open("registros.txt", "a")
        f.write("\n¿Nos recomendarias a algun amido o familiar?: ")
        f.write(question_10 + '\n¿por que? : ' + r_10)
        f.write("\n//////////////////////////////////////////////////////")
        f.close()

        return render_template('finish.html')

    elif '2' in request.form.values():

        question_10 = "2"
        r_10 = request.form['r_10']
        f = open("registros.txt", "a")
        f.write("\n¿Nos recomendarias a algun amido o familiar?: ")
        f.write(question_10 + '\n¿por que? : ' + r_10)
        f.write("\n//////////////////////////////////////////////////////")
        f.close()

        return render_template('finish.html')

    elif '3' in request.form.values():

        question_10 = "3"
        r_10 = request.form['r_10']
        f = open("registros.txt", "a")
        f.write("\n¿Nos recomendarias a algun amido o familiar?: ")
        f.write(question_10 + '\n¿por que? : ' + r_10)
        f.write("\n//////////////////////////////////////////////////////")
        f.close()

        return render_template('finish.html')

    elif '4' in request.form.values():

        question_10 = "4"
        r_10 = request.form['r_10']
        f = open("registros.txt", "a")
        f.write("\n¿Nos recomendarias a algun amido o familiar?: ")
        f.write(question_10 + '\n¿por que? : ' + r_10)
        f.write("\n//////////////////////////////////////////////////////")
        f.close()

        return render_template('finish.html')

    elif '5' in request.form.values():

        question_10 = "5"
        r_10 = request.form['r_10']
        f = open("registros.txt", "a")
        f.write("\n¿Nos recomendarias a algun amido o familiar?: ")
        f.write(question_10 + '\n¿por que? : ' + r_10)
        f.write("\n//////////////////////////////////////////////////////")
        f.close()

        return render_template('finish.html')

    return render_template('q10.html')

@app.route('/finish')
def finish():

    return render_template('finish.html')

if __name__ == '__main__':
    app.run()