function gracias(){
alert("¡Formulario Completado, Gracias!")
}